local projectileClass = {}
projectileClass.__index = projectileClass
function projectileClass:new(options)
    local obj = {
        x = options.x or 0,
        y = options.y or 0,
        vX = options.vX or 0,
        vY = options.vY or 0,
        speed = options.speed or 200,
        width = options.width or 8,
        height = options.height or 8,
        damage = options.damage or 1,
        lifetime = options.lifetime or 2, -- seconds
        age = 0,
        isExpired = false,
        image = options.imagePath or "sword"
    }
    setmetatable(obj, projectileClass)
    return obj
end
function projectileClass:draw()
    if not sprites[self.image] then
        return
    end
    love.graphics.draw(sprites[self.image], self.x, self.y)
end
function projectileClass:update(options)
    -- Move projectile in direction of Vx and Vy
    local dt = options.dt
    self.x = self.x + self.vX * self.speed * dt
    self.y = self.y + self.vY * self.speed * dt
    self.age = self.age + dt
    if self.age >= self.lifetime then
        self.isExpired = true
    end
end

-- Helper: find the closest enemy to a player from an enemySet
function projectileClass.findClosestEnemy(player, enemySet)
    if not enemySet then return nil end
    local best, bestDist = nil, math.huge
    for _, enemy in pairs(enemySet) do
        if enemy and (enemy.health == nil or enemy.health > 0) then
            local ex = (enemy.x or 0) + (enemy.width or 0)/2
            local ey = (enemy.y or 0) + (enemy.height or 0)/2
            local px = player.x + (player.width or 0)/2
            local py = player.y + (player.height or 0)/2
            local dx = ex - px
            local dy = ey - py
            local d = math.sqrt(dx*dx + dy*dy)
            if d < bestDist then bestDist = d; best = enemy end
        end
    end
    return best
end

return projectileClass